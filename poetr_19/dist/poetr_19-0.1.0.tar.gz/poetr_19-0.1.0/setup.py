# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['poetr_19']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['19day = poetr_19.Poetry19day:main']}

setup_kwargs = {
    'name': 'poetr-19',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Andreymazo',
    'author_email': 'andreymazo@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
